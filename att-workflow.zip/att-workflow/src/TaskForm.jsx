import { useState } from "react";

const FS = {
  width: "100%",
  background: "rgba(255,255,255,0.04)",
  border: "1px solid rgba(255,255,255,0.1)",
  borderRadius: 8,
  padding: "9px 12px",
  color: "#d4e8f7",
  fontSize: 13,
  fontFamily: "'Segoe UI', sans-serif",
  outline: "none",
  boxSizing: "border-box",
};

const LS = {
  color: "#5a7fa8", fontSize: 10, textTransform: "uppercase",
  letterSpacing: 1.5, fontWeight: 700, marginBottom: 5, display: "block",
};

const onFocus = (e) => { e.target.style.borderColor = "#00A8E0"; };
const onBlur  = (e) => { e.target.style.borderColor = "rgba(255,255,255,0.1)"; };

export default function TaskForm({ initialData, existingTasks, onSave, onClose }) {
  const isEditing = !!initialData;

  const [form, setForm] = useState(() => initialData ? { ...initialData } : {
    titulo: "", area_responsable: "", resumen_actividad: "",
    sla: "3 dias", se_trabajar_paralelo: "NO", insumos: "",
    estatus: "Pendiente", fecha_inicio: "", fecha_fin: "",
    evidencias_guias: "", categoria: "Alta Aplicación",
    scope: "No Productivo", dependencias: [],
  });

  const [error, setError] = useState("");
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const toggleDep = (id) => set("dependencias",
    form.dependencias.includes(id)
      ? form.dependencias.filter((d) => d !== id)
      : [...form.dependencias, id]
  );

  const handleSave = () => {
    if (!form.titulo.trim()) { setError("El título es obligatorio"); return; }
    onSave({ ...form, id: form.id || `T${Date.now()}` });
  };

  // Tareas disponibles para dependencias (excluir la propia si editando)
  const depOptions = existingTasks.filter((t) => t.id !== form.id);

  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)",
      backdropFilter: "blur(6px)", zIndex: 9999,
      display: "flex", alignItems: "center", justifyContent: "center", padding: 20,
    }}>
      <div onClick={(e) => e.stopPropagation()} style={{
        background: "linear-gradient(160deg, #0d1b2e 0%, #091526 100%)",
        border: "1px solid #00A8E044", borderRadius: 16,
        width: "100%", maxWidth: 580, maxHeight: "90vh",
        overflow: "hidden", display: "flex", flexDirection: "column",
        boxShadow: "0 24px 80px rgba(0,0,0,0.6), 0 0 40px rgba(0,168,224,0.15)",
        fontFamily: "'Segoe UI', sans-serif",
      }}>

        {/* Header */}
        <div style={{
          background: "linear-gradient(135deg, rgba(0,168,224,0.15) 0%, transparent 100%)",
          borderBottom: "1px solid rgba(0,168,224,0.2)",
          padding: "18px 24px", position: "relative",
        }}>
          <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 5, background: "#00A8E0", borderRadius: "16px 0 0 0" }} />
          <div style={{ paddingLeft: 12 }}>
            <div style={{ color: "#00A8E0", fontSize: 10, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", marginBottom: 4 }}>
              {isEditing ? "Editar Tarea" : "Nueva Tarea"}
            </div>
            <h2 style={{ color: "#fff", fontSize: 17, fontWeight: 800, margin: 0 }}>
              {isEditing ? `✎ ${form.titulo || "Sin título"}` : "✦ Agregar actividad al workflow"}
            </h2>
          </div>
          <button onClick={onClose} style={{
            position: "absolute", top: 14, right: 16,
            background: "rgba(255,255,255,0.07)", border: "1px solid rgba(255,255,255,0.12)",
            borderRadius: 8, width: 32, height: 32, cursor: "pointer",
            color: "#aaa", fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center",
          }}
            onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(255,68,68,0.2)"; e.currentTarget.style.color = "#ff4444"; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = "rgba(255,255,255,0.07)"; e.currentTarget.style.color = "#aaa"; }}
          >✕</button>
        </div>

        {/* Body */}
        <div style={{ overflowY: "auto", padding: "20px 24px", flex: 1 }}>
          {error && (
            <div style={{ background: "rgba(255,68,68,0.12)", border: "1px solid rgba(255,68,68,0.3)", borderRadius: 8, padding: "9px 14px", color: "#ff6b6b", fontSize: 12, marginBottom: 16 }}>
              ⚠ {error}
            </div>
          )}

          <div style={{ marginBottom: 14 }}>
            <label style={LS}>📌 Título *</label>
            <input value={form.titulo} onChange={(e) => set("titulo", e.target.value)}
              onFocus={onFocus} onBlur={onBlur} placeholder="Ej. Alta en Dynatrace" style={FS} />
          </div>

          <div style={{ marginBottom: 14 }}>
            <label style={LS}>👥 Área Responsable</label>
            <input value={form.area_responsable} onChange={(e) => set("area_responsable", e.target.value)}
              onFocus={onFocus} onBlur={onBlur} placeholder="Equipo <correo@mx.att.com>" style={FS} />
          </div>

          <div style={{ marginBottom: 14 }}>
            <label style={LS}>📋 Resumen de Actividad</label>
            <textarea value={form.resumen_actividad} onChange={(e) => set("resumen_actividad", e.target.value)}
              onFocus={onFocus} onBlur={onBlur} placeholder="Descripción de lo que se debe hacer..."
              rows={3} style={{ ...FS, resize: "vertical" }} />
          </div>

          <div style={{ display: "flex", gap: 12, marginBottom: 14 }}>
            <div style={{ flex: 1 }}>
              <label style={LS}>⏱ SLA</label>
              <select value={form.sla} onChange={(e) => set("sla", e.target.value)} onFocus={onFocus} onBlur={onBlur} style={FS}>
                {["1 dia","2 dias","3 dias","5 dias","7 dias","10 dias"].map(v => <option key={v} value={v} style={{ background: "#0d1b2e" }}>{v}</option>)}
              </select>
            </div>
            <div style={{ flex: 1 }}>
              <label style={LS}>⫴ Trabaja en Paralelo</label>
              <select value={form.se_trabajar_paralelo} onChange={(e) => set("se_trabajar_paralelo", e.target.value)} onFocus={onFocus} onBlur={onBlur} style={FS}>
                <option value="SI" style={{ background: "#0d1b2e" }}>SI</option>
                <option value="NO" style={{ background: "#0d1b2e" }}>NO</option>
              </select>
            </div>
          </div>

          <div style={{ display: "flex", gap: 12, marginBottom: 14 }}>
            <div style={{ flex: 1 }}>
              <label style={LS}>🔘 Estatus</label>
              <select value={form.estatus} onChange={(e) => set("estatus", e.target.value)} onFocus={onFocus} onBlur={onBlur} style={FS}>
                {["Proceso","Pendiente","Bloqueado","Completado"].map(v => <option key={v} value={v} style={{ background: "#0d1b2e" }}>{v}</option>)}
              </select>
            </div>
            <div style={{ flex: 1 }}>
              <label style={LS}>🎯 Scope</label>
              <select value={form.scope} onChange={(e) => set("scope", e.target.value)} onFocus={onFocus} onBlur={onBlur} style={FS}>
                <option value="No Productivo" style={{ background: "#0d1b2e" }}>No Productivo</option>
                <option value="Productivo" style={{ background: "#0d1b2e" }}>Productivo</option>
              </select>
            </div>
          </div>

          <div style={{ display: "flex", gap: 12, marginBottom: 14 }}>
            <div style={{ flex: 1 }}>
              <label style={LS}>📅 Fecha Inicio</label>
              <input type="date" value={form.fecha_inicio} onChange={(e) => set("fecha_inicio", e.target.value)}
                onFocus={onFocus} onBlur={onBlur} style={{ ...FS, colorScheme: "dark" }} />
            </div>
            <div style={{ flex: 1 }}>
              <label style={LS}>🏁 Fecha Fin</label>
              <input type="date" value={form.fecha_fin} onChange={(e) => set("fecha_fin", e.target.value)}
                onFocus={onFocus} onBlur={onBlur} style={{ ...FS, colorScheme: "dark" }} />
            </div>
          </div>

          <div style={{ marginBottom: 14 }}>
            <label style={LS}>📎 Insumos</label>
            <input value={form.insumos} onChange={(e) => set("insumos", e.target.value)}
              onFocus={onFocus} onBlur={onBlur} placeholder="Archivos, tickets, correos adjuntos..." style={FS} />
          </div>

          <div style={{ marginBottom: 14 }}>
            <label style={LS}>📄 Evidencias / Guías</label>
            <input value={form.evidencias_guias} onChange={(e) => set("evidencias_guias", e.target.value)}
              onFocus={onFocus} onBlur={onBlur} placeholder="Nombre de archivo .msg, captura, etc." style={FS} />
          </div>

          {/* Dependencias */}
          {depOptions.length > 0 && (
            <div style={{ marginBottom: 14 }}>
              <label style={LS}>🔗 Depende de (opcional)</label>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {depOptions.map((t) => {
                  const active = form.dependencias.includes(t.id);
                  return (
                    <button key={t.id} onClick={() => toggleDep(t.id)} style={{
                      background: active ? "rgba(0,168,224,0.15)" : "rgba(255,255,255,0.04)",
                      border: `1px solid ${active ? "#00A8E0" : "rgba(255,255,255,0.1)"}`,
                      borderRadius: 6, padding: "5px 12px", cursor: "pointer",
                      color: active ? "#00A8E0" : "#888", fontSize: 11,
                      fontFamily: "inherit", transition: "all 0.15s",
                    }}>
                      #{t.id} {t.titulo.length > 22 ? t.titulo.slice(0, 22) + "…" : t.titulo}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{
          borderTop: "1px solid rgba(255,255,255,0.06)",
          padding: "14px 24px", display: "flex", justifyContent: "flex-end", gap: 10,
        }}>
          <button onClick={onClose} style={{
            background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
            borderRadius: 8, padding: "9px 20px", color: "#aaa",
            fontSize: 13, cursor: "pointer", fontFamily: "inherit",
          }}>Cancelar</button>
          <button onClick={handleSave} style={{
            background: "linear-gradient(135deg, #00A8E0, #0078a8)",
            border: "none", borderRadius: 8, padding: "9px 24px",
            color: "#fff", fontSize: 13, fontWeight: 700, cursor: "pointer",
            fontFamily: "inherit", boxShadow: "0 0 16px rgba(0,168,224,0.35)",
          }}
            onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "0 0 24px rgba(0,168,224,0.55)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "0 0 16px rgba(0,168,224,0.35)"; }}
          >
            {isEditing ? "✎ Guardar cambios" : "✦ Crear Tarea"}
          </button>
        </div>
      </div>
    </div>
  );
}
