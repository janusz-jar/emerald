import { useState, useCallback, useMemo, useEffect } from "react";
import ReactFlow, {
  MiniMap, Controls, Background,
  useNodesState, useEdgesState, addEdge,
  MarkerType, Panel,
} from "reactflow";
import "reactflow/dist/style.css";
import TaskNode from "./TaskNode";
import TaskModal from "./TaskModal";
import TaskForm from "./TaskForm";

// ─── Persistencia — tareas.json ───────────────────────────────────────────────
// Electron  → window.api  (IPC → fs, archivo junto al .exe)
// Browser   → localStorage  (fallback para npm run dev)
const LS_KEY = "att-tareas-json";

const DEFAULT_TAREAS = [
  { id:"1", titulo:"Alta Repositorio APM ServicesNow", area_responsable:"Mexico IT iTAP <Mexico.IT.iTAP@mx.att.com> / Arquitectura Aplicaciones", resumen_actividad:"Se requiere tener el APM correspondiente a la aplicación afectada dada de alta en SNOW", sla:"3 dias", se_trabajar_paralelo:"SI", insumos:"se adjunta correo", estatus:"Proceso", fecha_inicio:"29/04/2026", fecha_fin:"", evidencias_guias:"Tarea_ALTA_APM_ Apoyo últimos puntos para registro de Aplicación de Negocio TMFProducts.msg", categoria:"Alta Aplicación", scope:"No Productivo", dependencias:[] },
  { id:"2.1", titulo:"Alta Repositorio GitHub", area_responsable:"Mexico IT Administracion Configuracion <mexicoitadministracionconfiguracion@mx.att.com>", resumen_actividad:"La Aplicación de negocio necesita repositorios de código y documentación en github afectada dada de alta en SNOW", sla:"3 dias", se_trabajar_paralelo:"SI", insumos:"Alta Repositorio GitHub MXAPM0002643 SFFEAT0004464 ApiGetBalance Meli consultaSuscriptorMeli-orchestator.msg", estatus:"Proceso", fecha_inicio:"29/04/2026", fecha_fin:"", evidencias_guias:"Repositorios GIT", categoria:"Alta Aplicación", scope:"No Productivo", dependencias:[] },
  { id:"2.2", titulo:"Alta SonarQube", area_responsable:"Mexico IT Calidad de Software <mexicoitcalidaddesoftware@mx.att.com>", resumen_actividad:"Se requiere dar de alta el proyecto en SonarQube para análisis de calidad de código", sla:"3 dias", se_trabajar_paralelo:"SI", insumos:"Ticket SNOW con datos de la aplicación", estatus:"Pendiente", fecha_inicio:"29/04/2026", fecha_fin:"", evidencias_guias:"Captura de pantalla proyecto SonarQube", categoria:"Alta Aplicación", scope:"No Productivo", dependencias:[] },
  { id:"2.3", titulo:"Alta Nexus / Artifactory", area_responsable:"Mexico IT Administracion Configuracion <mexicoitadministracionconfiguracion@mx.att.com>", resumen_actividad:"Dar de alta los repositorios de artefactos en Nexus/Artifactory para la aplicación", sla:"3 dias", se_trabajar_paralelo:"SI", insumos:"Ticket SNOW y nombre del repositorio", estatus:"Pendiente", fecha_inicio:"29/04/2026", fecha_fin:"", evidencias_guias:"Repositorio creado en Nexus", categoria:"Alta Aplicación", scope:"No Productivo", dependencias:[] },
  { id:"3", titulo:"Configuración Pipeline CI/CD", area_responsable:"Mexico IT DevOps <mexicoitdevops@mx.att.com>", resumen_actividad:"Configurar el pipeline de integración y entrega continua en Jenkins/Azure DevOps", sla:"5 dias", se_trabajar_paralelo:"NO", insumos:"Repositorio GitHub creado, SonarQube y Nexus configurados", estatus:"Bloqueado", fecha_inicio:"", fecha_fin:"", evidencias_guias:"Pipeline ejecutado exitosamente", categoria:"Alta Aplicación", scope:"No Productivo", dependencias:["2.1","2.2","2.3"] },
  { id:"4", titulo:"Alta en API Gateway", area_responsable:"Mexico IT Arquitectura <mexicoitarquitectura@mx.att.com>", resumen_actividad:"Registrar los endpoints de la aplicación en el API Gateway corporativo", sla:"3 dias", se_trabajar_paralelo:"NO", insumos:"Especificación OpenAPI/Swagger de los servicios", estatus:"Bloqueado", fecha_inicio:"", fecha_fin:"", evidencias_guias:"API registrada y disponible en gateway", categoria:"Alta Aplicación", scope:"No Productivo", dependencias:["3"] },
  { id:"5", titulo:"Validación y Cierre", area_responsable:"Mexico IT iTAP <Mexico.IT.iTAP@mx.att.com>", resumen_actividad:"Validar que todos los componentes están correctamente configurados y cerrar el ticket SNOW", sla:"2 dias", se_trabajar_paralelo:"NO", insumos:"Evidencias de todas las tareas anteriores", estatus:"Bloqueado", fecha_inicio:"", fecha_fin:"", evidencias_guias:"Ticket SNOW cerrado con evidencias", categoria:"Alta Aplicación", scope:"No Productivo", dependencias:["1","3","4"] },
];

async function loadTareas() {
  if (window.api) {
    const data = await window.api.readTareas();
    return data?.tareas ?? DEFAULT_TAREAS;
  }
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? JSON.parse(raw) : DEFAULT_TAREAS;
  } catch { return DEFAULT_TAREAS; }
}

async function saveTareas(tareas) {
  if (window.api) {
    await window.api.writeTareas({ tareas });
  } else {
    localStorage.setItem(LS_KEY, JSON.stringify(tareas));
  }
}
// ─────────────────────────────────────────────────────────────────────────────

function buildLayout(tasks) {
  const nodes = [], edges = [], depMap = {};
  tasks.forEach((t) => (depMap[t.id] = t.dependencias || []));

  const levels = {}, visited = new Set();
  function getLevel(id) {
    if (levels[id] !== undefined) return levels[id];
    if (visited.has(id)) return 0;
    visited.add(id);
    const deps = depMap[id] || [];
    levels[id] = deps.length === 0 ? 0 : Math.max(...deps.map(getLevel)) + 1;
    return levels[id];
  }
  tasks.forEach((t) => getLevel(t.id));

  const byLevel = {};
  tasks.forEach((t) => {
    const lvl = levels[t.id];
    if (!byLevel[lvl]) byLevel[lvl] = [];
    byLevel[lvl].push(t);
  });

  const NODE_W = 280, NODE_H = 120, H_GAP = 60, V_GAP = 80;
  Object.entries(byLevel).forEach(([lvl, group]) => {
    const level = parseInt(lvl);
    const totalW = group.length * NODE_W + (group.length - 1) * H_GAP;
    const startX = -totalW / 2;
    group.forEach((task, i) => {
      nodes.push({
        id: task.id, type: "taskNode",
        position: { x: startX + i * (NODE_W + H_GAP), y: level * (NODE_H + V_GAP) },
        data: { task, isParallel: task.se_trabajar_paralelo === "SI" },
      });
    });
  });

  tasks.forEach((task) => {
    (task.dependencias || []).forEach((depId) => {
      edges.push({
        id: `${depId}->${task.id}`, source: depId, target: task.id,
        type: "smoothstep",
        markerEnd: { type: MarkerType.ArrowClosed, color: "#00A8E0" },
        style: { stroke: "#00A8E0", strokeWidth: 2 },
      });
    });
  });

  return { nodes, edges };
}

const nodeTypes = { taskNode: TaskNode };
const STATUS_OPTIONS = ["Proceso", "Pendiente", "Bloqueado", "Completado"];

export default function App() {
  const [tareas, setTareas] = useState(DEFAULT_TAREAS);
  const [loaded, setLoaded] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingTask, setEditingTask] = useState(null); // para editar desde modal

  // Cargar tareas.json al montar
  useEffect(() => {
    loadTareas().then((data) => {
      setTareas(data);
      setLoaded(true);
    });
  }, []);

  // Guardar cada vez que cambia tareas (post carga)
  useEffect(() => {
    if (!loaded) return;
    saveTareas(tareas);
  }, [tareas, loaded]);

  // ── Acciones ──────────────────────────────────────────────────────────────

  // Cambiar estatus de una tarea
  const updateStatus = useCallback((taskId, newStatus) => {
    setTareas((prev) => prev.map((t) => t.id === taskId ? { ...t, estatus: newStatus } : t));
    setSelectedTask((prev) => prev?.id === taskId ? { ...prev, estatus: newStatus } : prev);
  }, []);

  // Guardar tarea nueva o editada
  const saveTask = useCallback((taskData) => {
    setTareas((prev) => {
      const exists = prev.find((t) => t.id === taskData.id);
      if (exists) return prev.map((t) => t.id === taskData.id ? taskData : t);
      return [...prev, taskData];
    });
    setShowForm(false);
    setEditingTask(null);
    setSelectedTask(null);
  }, []);

  // Abrir formulario de edición desde el modal
  const openEdit = useCallback((task) => {
    setEditingTask(task);
    setSelectedTask(null);
    setShowForm(true);
  }, []);

  // ── Layout ────────────────────────────────────────────────────────────────
  const { nodes: layoutNodes, edges: layoutEdges } = useMemo(
    () => buildLayout(tareas), [tareas]
  );

  const [nodes, , onNodesChange] = useNodesState(layoutNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(layoutEdges);

  // Sincronizar nodos cuando cambia tareas
  const syncedNodes = useMemo(() =>
    layoutNodes.map((n) => {
      const live = tareas.find((t) => t.id === n.id);
      return live ? { ...n, data: { ...n.data, task: live, isParallel: live.se_trabajar_paralelo === "SI" } } : n;
    }),
    [layoutNodes, tareas]
  );

  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)), [setEdges]
  );

  const onNodeClick = useCallback((_, node) => {
    const live = tareas.find((t) => t.id === node.id) ?? node.data.task;
    setSelectedTask(live);
  }, [tareas]);

  const statusCounts = useMemo(() => {
    const counts = { Proceso: 0, Pendiente: 0, Bloqueado: 0, Completado: 0 };
    tareas.forEach((t) => { if (counts[t.estatus] !== undefined) counts[t.estatus]++; });
    return counts;
  }, [tareas]);

  const isElectron = !!window.api;

  return (
    <div style={{ width: "100vw", height: "100vh", background: "#0a0e1a", fontFamily: "'Segoe UI', sans-serif" }}>
      <ReactFlow
        nodes={syncedNodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onNodeClick={onNodeClick}
        nodeTypes={nodeTypes}
        fitView fitViewOptions={{ padding: 0.3 }}
        minZoom={0.3} maxZoom={2}
      >
        <Background color="#1a2035" gap={24} size={1} />
        <Controls style={{ background: "#111827", border: "1px solid #1e3a5f", borderRadius: 8 }} />

        {/* Título top-center */}
        <Panel position="top-center">
          <div style={{
            display: "flex", alignItems: "center", gap: 12,
            background: "linear-gradient(135deg, #0d1b2a 0%, #1a2f4a 100%)",
            border: "1px solid #00A8E033", borderRadius: 14,
            padding: "10px 24px", boxShadow: "0 4px 32px rgba(0,168,224,0.12)",
          }}>
            <span style={{ fontSize: 22 }}>🍳</span>
            <div>
              <div style={{ color: "#00A8E0", fontSize: 10, fontWeight: 700, letterSpacing: 2.5, textTransform: "uppercase" }}>AT&T México · Arquitectura</div>
              <div style={{ color: "#ffffff", fontSize: 20, fontWeight: 900, letterSpacing: 0.5, textShadow: "0 0 20px rgba(255,255,255,0.3)" }}>
                Receta de Microservicios
              </div>
            </div>
            <span style={{ color: "#5a7fa8", fontSize: 11, fontStyle: "italic", marginLeft: 8, alignSelf: "flex-end", paddingBottom: 2 }}>
              sirve caliente y sin dependencias circulares 🌶️
            </span>
          </div>
        </Panel>

        <MiniMap
          style={{ background: "#111827", border: "1px solid #1e3a5f" }}
          nodeColor={(n) => {
            const t = tareas.find((t) => t.id === n.id);
            const s = t?.estatus;
            if (s === "Proceso") return "#00A8E0";
            if (s === "Completado") return "#00C851";
            if (s === "Bloqueado") return "#FF4444";
            return "#F5A623";
          }}
        />

        {/* Panel bottom-left */}
        <Panel position="bottom-left">
          <div style={{
            background: "linear-gradient(135deg, #0d1b2a 0%, #1a2f4a 100%)",
            border: "1px solid #00A8E0", borderRadius: 12,
            padding: "16px 20px", minWidth: 340,
            boxShadow: "0 4px 24px rgba(0,168,224,0.15)",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
              <div style={{
                background: "linear-gradient(135deg, #00A8E0, #0078a8)", borderRadius: 8,
                width: 42, height: 42, display: "flex", alignItems: "center",
                justifyContent: "center", fontSize: 22, flexShrink: 0,
                boxShadow: "0 0 12px rgba(0,168,224,0.4)",
              }}>🍳</div>
              <div>
                <div style={{ color: "#00A8E0", fontSize: 10, fontWeight: 700, letterSpacing: 2.5, textTransform: "uppercase" }}>AT&T México · Arquitectura</div>
                <div style={{ color: "#ffffff", fontSize: 17, fontWeight: 900, textShadow: "0 0 20px rgba(255,255,255,0.3)" }}>Receta de Microservicios</div>
                <div style={{ color: "#5a7fa8", fontSize: 10, fontStyle: "italic" }}>sirve caliente y sin dependencias circulares 🌶️</div>
              </div>
            </div>

            {/* Contadores */}
            <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
              {Object.entries(statusCounts).map(([status, count]) => (
                <div key={status} style={{
                  background: "rgba(255,255,255,0.05)",
                  border: `1px solid ${status === "Proceso" ? "#00A8E0" : status === "Completado" ? "#00C851" : status === "Bloqueado" ? "#FF4444" : "#F5A623"}`,
                  borderRadius: 6, padding: "4px 8px", textAlign: "center", flex: 1,
                }}>
                  <div style={{ color: "#aaa", fontSize: 9, textTransform: "uppercase", letterSpacing: 1 }}>{status}</div>
                  <div style={{ color: "#fff", fontSize: 16, fontWeight: 700 }}>{count}</div>
                </div>
              ))}
            </div>

            {/* Botón nueva tarea */}
            <button
              onClick={() => { setEditingTask(null); setShowForm(true); }}
              style={{
                width: "100%", background: "linear-gradient(135deg, #00A8E0, #0078a8)",
                border: "none", borderRadius: 8, padding: "10px",
                color: "#fff", fontSize: 13, fontWeight: 700, cursor: "pointer",
                fontFamily: "inherit", boxShadow: "0 0 16px rgba(0,168,224,0.3)",
                display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
              }}
              onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "0 0 24px rgba(0,168,224,0.55)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "0 0 16px rgba(0,168,224,0.3)"; }}
            >
              ✦ Nueva Tarea
            </button>

            {/* Indicador de persistencia */}
            <div style={{ marginTop: 8, display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{ width: 7, height: 7, borderRadius: "50%", background: isElectron ? "#00C851" : "#F5A623", boxShadow: `0 0 6px ${isElectron ? "#00C851" : "#F5A623"}` }} />
              <span style={{ color: "#3a5a6a", fontSize: 10 }}>
                {isElectron ? "💾 tareas.json · junto al ejecutable" : "🌐 localStorage · modo dev"}
              </span>
            </div>
          </div>
        </Panel>

        {/* Leyenda top-right */}
        <Panel position="top-right">
          <div style={{ background: "rgba(13,27,42,0.95)", border: "1px solid #1e3a5f", borderRadius: 10, padding: "12px 16px", fontSize: 12 }}>
            <div style={{ color: "#00A8E0", fontWeight: 700, marginBottom: 8, fontSize: 11, letterSpacing: 1, textTransform: "uppercase" }}>Leyenda</div>
            {[{ color: "#00A8E0", label: "En Proceso" }, { color: "#F5A623", label: "Pendiente" }, { color: "#FF4444", label: "Bloqueado" }, { color: "#00C851", label: "Completado" }].map(({ color, label }) => (
              <div key={label} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 5 }}>
                <div style={{ width: 10, height: 10, borderRadius: "50%", background: color }} />
                <span style={{ color: "#ccc" }}>{label}</span>
              </div>
            ))}
            <div style={{ borderTop: "1px solid #1e3a5f", marginTop: 8, paddingTop: 8 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 20, height: 2, background: "#00A8E0", borderRadius: 1 }} />
                <span style={{ color: "#ccc" }}>Dependencia</span>
              </div>
            </div>
          </div>
        </Panel>
      </ReactFlow>

      {/* Modal detalle */}
      {selectedTask && (
        <TaskModal
          task={selectedTask}
          statusOptions={STATUS_OPTIONS}
          onStatusChange={(s) => updateStatus(selectedTask.id, s)}
          onEdit={() => openEdit(selectedTask)}
          onClose={() => setSelectedTask(null)}
        />
      )}

      {/* Formulario crear/editar */}
      {showForm && (
        <TaskForm
          initialData={editingTask}
          existingTasks={tareas}
          onSave={saveTask}
          onClose={() => { setShowForm(false); setEditingTask(null); }}
        />
      )}
    </div>
  );
}