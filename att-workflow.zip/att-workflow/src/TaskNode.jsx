import { Handle, Position } from "reactflow";

const STATUS_COLORS = {
  Proceso: { bg: "#00A8E0", border: "#00A8E0", glow: "0 0 16px rgba(0,168,224,0.4)" },
  Pendiente: { bg: "#F5A623", border: "#F5A623", glow: "0 0 16px rgba(245,166,35,0.3)" },
  Bloqueado: { bg: "#FF4444", border: "#FF4444", glow: "0 0 16px rgba(255,68,68,0.3)" },
  Completado: { bg: "#00C851", border: "#00C851", glow: "0 0 16px rgba(0,200,81,0.3)" },
};

const STATUS_ICONS = {
  Proceso: "⟳",
  Pendiente: "◷",
  Bloqueado: "⊘",
  Completado: "✓",
};

export default function TaskNode({ data, selected }) {
  const { task, isParallel } = data;
  const statusStyle = STATUS_COLORS[task.estatus] || STATUS_COLORS.Pendiente;
  const icon = STATUS_ICONS[task.estatus] || "○";

  return (
    <div style={{
      background: selected
        ? "linear-gradient(135deg, #0d2240 0%, #0a1a35 100%)"
        : "linear-gradient(135deg, #0d1b2e 0%, #091526 100%)",
      border: `2px solid ${selected ? "#00A8E0" : statusStyle.border}`,
      borderRadius: 12,
      padding: "14px 16px",
      width: 280,
      minHeight: 110,
      cursor: "pointer",
      boxShadow: selected
        ? `0 0 24px rgba(0,168,224,0.5), inset 0 0 24px rgba(0,168,224,0.05)`
        : statusStyle.glow,
      transition: "all 0.2s ease",
      position: "relative",
      overflow: "hidden",
    }}>
      {/* Parallel badge */}
      {isParallel && (
        <div style={{
          position: "absolute",
          top: 8,
          right: 8,
          background: "rgba(0,168,224,0.15)",
          border: "1px solid rgba(0,168,224,0.4)",
          borderRadius: 4,
          padding: "2px 6px",
          fontSize: 9,
          color: "#00A8E0",
          fontWeight: 700,
          letterSpacing: 1,
          textTransform: "uppercase",
        }}>
          ⫴ PARALELO
        </div>
      )}

      {/* Accent line */}
      <div style={{
        position: "absolute",
        left: 0,
        top: 0,
        bottom: 0,
        width: 4,
        background: statusStyle.bg,
        borderRadius: "12px 0 0 12px",
      }} />

      <div style={{ paddingLeft: 8 }}>
        {/* ID + Status */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
          <span style={{
            background: "rgba(0,168,224,0.1)",
            border: "1px solid rgba(0,168,224,0.3)",
            borderRadius: 4,
            padding: "1px 6px",
            fontSize: 10,
            color: "#00A8E0",
            fontWeight: 700,
            fontFamily: "monospace",
          }}>
            #{task.id}
          </span>
          <span style={{
            background: `${statusStyle.bg}22`,
            border: `1px solid ${statusStyle.border}55`,
            borderRadius: 4,
            padding: "1px 6px",
            fontSize: 10,
            color: statusStyle.bg,
            fontWeight: 600,
          }}>
            {icon} {task.estatus}
          </span>
        </div>

        {/* Title */}
        <div style={{
          color: "#ffffff",
          fontSize: 13,
          fontWeight: 700,
          lineHeight: 1.3,
          marginBottom: 8,
          paddingRight: isParallel ? 70 : 0,
        }}>
          {task.titulo}
        </div>

        {/* Meta */}
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <span style={{ fontSize: 10, color: "#5a7fa8" }}>⏱ SLA:</span>
            <span style={{ fontSize: 10, color: "#8ab4cc", fontWeight: 600 }}>{task.sla}</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <span style={{ fontSize: 10, color: "#5a7fa8" }}>📁</span>
            <span style={{ fontSize: 10, color: "#8ab4cc" }}>{task.categoria}</span>
          </div>
        </div>

        {/* Scope badge */}
        <div style={{ marginTop: 8 }}>
          <span style={{
            background: task.scope === "Productivo" ? "rgba(0,200,81,0.1)" : "rgba(245,166,35,0.1)",
            border: `1px solid ${task.scope === "Productivo" ? "#00C85155" : "#F5A62355"}`,
            borderRadius: 4,
            padding: "2px 8px",
            fontSize: 9,
            color: task.scope === "Productivo" ? "#00C851" : "#F5A623",
            fontWeight: 600,
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}>
            {task.scope}
          </span>
        </div>
      </div>

      <Handle
        type="target"
        position={Position.Top}
        style={{ background: "#00A8E0", border: "2px solid #0a1a35", width: 10, height: 10 }}
      />
      <Handle
        type="source"
        position={Position.Bottom}
        style={{ background: "#00A8E0", border: "2px solid #0a1a35", width: 10, height: 10 }}
      />
    </div>
  );
}
