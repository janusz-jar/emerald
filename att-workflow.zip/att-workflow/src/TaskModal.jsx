const STATUS_COLORS = {
  Proceso: "#00A8E0", Pendiente: "#F5A623",
  Bloqueado: "#FF4444", Completado: "#00C851",
};
const STATUS_ICONS = { Proceso: "⟳", Pendiente: "◷", Bloqueado: "⊘", Completado: "✓" };

function Field({ label, value, icon, mono }) {
  if (!value) return null;
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ color: "#5a7fa8", fontSize: 10, textTransform: "uppercase", letterSpacing: 1.5, fontWeight: 700, marginBottom: 4, display: "flex", alignItems: "center", gap: 6 }}>
        {icon && <span>{icon}</span>}{label}
      </div>
      <div style={{ color: mono ? "#a8d4f0" : "#d4e8f7", fontSize: 13, lineHeight: 1.6, background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 6, padding: "8px 12px", fontFamily: mono ? "monospace" : "inherit", wordBreak: "break-word" }}>
        {value}
      </div>
    </div>
  );
}

export default function TaskModal({ task, statusOptions, onStatusChange, onEdit, onClose }) {
  const statusColor = STATUS_COLORS[task.estatus] || "#aaa";
  const isCompleted = task.estatus === "Completado";

  const emailMatch = task.area_responsable?.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-z]{2,}/);
  const email = emailMatch ? emailMatch[0] : null;
  const areaName = task.area_responsable?.replace(/<[^>]+>/g, "").trim();

  return (
    <div onClick={onClose} style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)",
      backdropFilter: "blur(6px)", zIndex: 9999,
      display: "flex", alignItems: "center", justifyContent: "center", padding: 20,
    }}>
      <div onClick={(e) => e.stopPropagation()} style={{
        background: "linear-gradient(160deg, #0d1b2e 0%, #091526 100%)",
        border: `1px solid ${statusColor}44`, borderRadius: 16,
        width: "100%", maxWidth: 600, maxHeight: "85vh",
        overflow: "hidden", display: "flex", flexDirection: "column",
        boxShadow: `0 24px 80px rgba(0,0,0,0.6), 0 0 40px ${statusColor}22`,
        fontFamily: "'Segoe UI', sans-serif",
      }}>

        {/* Header */}
        <div style={{
          background: `linear-gradient(135deg, ${statusColor}22 0%, transparent 100%)`,
          borderBottom: `1px solid ${statusColor}33`,
          padding: "20px 24px", position: "relative",
        }}>
          <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 5, background: statusColor, borderRadius: "16px 0 0 0" }} />
          <div style={{ paddingLeft: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8, flexWrap: "wrap" }}>
              <span style={{ background: `${statusColor}22`, border: `1px solid ${statusColor}55`, borderRadius: 6, padding: "3px 10px", fontSize: 11, color: statusColor, fontWeight: 700, fontFamily: "monospace" }}>
                TAREA #{task.id}
              </span>
              <span style={{ background: `${statusColor}18`, border: `1px solid ${statusColor}44`, borderRadius: 6, padding: "3px 10px", fontSize: 11, color: statusColor, fontWeight: 600 }}>
                {STATUS_ICONS[task.estatus]} {task.estatus}
              </span>
              {task.se_trabajar_paralelo === "SI" && (
                <span style={{ background: "rgba(0,168,224,0.12)", border: "1px solid rgba(0,168,224,0.35)", borderRadius: 6, padding: "3px 10px", fontSize: 11, color: "#00A8E0", fontWeight: 700 }}>
                  ⫴ PARALELO
                </span>
              )}
            </div>
            <h2 style={{ color: "#ffffff", fontSize: 18, fontWeight: 800, margin: 0, lineHeight: 1.3 }}>{task.titulo}</h2>
          </div>
          <button onClick={onClose} style={{
            position: "absolute", top: 16, right: 16,
            background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)",
            borderRadius: 8, width: 32, height: 32, cursor: "pointer",
            color: "#aaa", fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center",
          }}
            onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(255,68,68,0.2)"; e.currentTarget.style.color = "#ff4444"; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = "rgba(255,255,255,0.08)"; e.currentTarget.style.color = "#aaa"; }}
          >✕</button>
        </div>

        {/* Body */}
        <div style={{ overflowY: "auto", padding: "20px 24px", flex: 1 }}>

          {/* Cambiar estatus */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ color: "#5a7fa8", fontSize: 10, textTransform: "uppercase", letterSpacing: 1.5, fontWeight: 700, marginBottom: 8 }}>🔄 Cambiar Estatus</div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {statusOptions.map((s) => {
                const isActive = task.estatus === s;
                const c = STATUS_COLORS[s];
                return (
                  <button key={s} onClick={() => onStatusChange(s)} style={{
                    background: isActive ? `${c}22` : "rgba(255,255,255,0.04)",
                    border: `2px solid ${isActive ? c : "rgba(255,255,255,0.1)"}`,
                    borderRadius: 8, padding: "7px 16px", cursor: "pointer",
                    color: isActive ? c : "#aaa", fontSize: 12, fontWeight: isActive ? 700 : 400,
                    fontFamily: "inherit", transition: "all 0.15s",
                    boxShadow: isActive ? `0 0 12px ${c}44` : "none",
                  }}
                    onMouseEnter={(e) => { if (!isActive) { e.currentTarget.style.borderColor = c; e.currentTarget.style.color = c; }}}
                    onMouseLeave={(e) => { if (!isActive) { e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; e.currentTarget.style.color = "#aaa"; }}}
                  >
                    {STATUS_ICONS[s]} {s}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick stats */}
          <div style={{ display: "flex", gap: 10, marginBottom: 20, flexWrap: "wrap" }}>
            {[{ label: "SLA", value: task.sla, icon: "⏱" }, { label: "Categoría", value: task.categoria, icon: "📁" }, { label: "Scope", value: task.scope, icon: "🎯" }].map(({ label, value, icon }) => (
              <div key={label} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 8, padding: "8px 16px", flex: 1, minWidth: 100 }}>
                <div style={{ color: "#5a7fa8", fontSize: 10, textTransform: "uppercase", letterSpacing: 1 }}>{icon} {label}</div>
                <div style={{ color: "#d4e8f7", fontSize: 14, fontWeight: 600, marginTop: 3 }}>{value}</div>
              </div>
            ))}
          </div>

          {(task.fecha_inicio || task.fecha_fin) && (
            <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
              {task.fecha_inicio && (
                <div style={{ background: "rgba(0,168,224,0.08)", border: "1px solid rgba(0,168,224,0.2)", borderRadius: 8, padding: "8px 14px", flex: 1 }}>
                  <div style={{ color: "#5a7fa8", fontSize: 10, textTransform: "uppercase", letterSpacing: 1 }}>📅 Inicio</div>
                  <div style={{ color: "#00A8E0", fontSize: 14, fontWeight: 700, marginTop: 3 }}>{task.fecha_inicio}</div>
                </div>
              )}
              {task.fecha_fin && (
                <div style={{ background: "rgba(0,200,81,0.08)", border: "1px solid rgba(0,200,81,0.2)", borderRadius: 8, padding: "8px 14px", flex: 1 }}>
                  <div style={{ color: "#5a7fa8", fontSize: 10, textTransform: "uppercase", letterSpacing: 1 }}>🏁 Fin</div>
                  <div style={{ color: "#00C851", fontSize: 14, fontWeight: 700, marginTop: 3 }}>{task.fecha_fin}</div>
                </div>
              )}
            </div>
          )}

          <Field label="Resumen de Actividad" value={task.resumen_actividad} icon="📋" />

          <div style={{ marginBottom: 14 }}>
            <div style={{ color: "#5a7fa8", fontSize: 10, textTransform: "uppercase", letterSpacing: 1.5, fontWeight: 700, marginBottom: 4 }}>👥 Área Responsable</div>
            <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 6, padding: "10px 12px" }}>
              <div style={{ color: "#d4e8f7", fontSize: 13, marginBottom: email ? 8 : 0 }}>{areaName}</div>
              {email && (
                <a href={`mailto:${email}`} style={{
                  display: "inline-flex", alignItems: "center", gap: 6,
                  background: "rgba(0,168,224,0.12)", border: "1px solid rgba(0,168,224,0.3)",
                  borderRadius: 6, padding: "4px 12px", color: "#00A8E0",
                  fontSize: 12, textDecoration: "none", fontWeight: 600,
                }}
                  onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(0,168,224,0.22)"; }}
                  onMouseLeave={(e) => { e.currentTarget.style.background = "rgba(0,168,224,0.12)"; }}
                >✉ {email}</a>
              )}
            </div>
          </div>

          <Field label="Insumos" value={task.insumos} icon="📎" />
          <Field label="Evidencias / Guías" value={task.evidencias_guias} icon="📄" mono />
        </div>

        {/* Footer */}
        <div style={{
          borderTop: "1px solid rgba(255,255,255,0.06)",
          padding: "12px 24px", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10,
        }}>
          <div style={{ display: "flex", gap: 8 }}>
            {/* Marcar completada */}
            {!isCompleted ? (
              <button onClick={() => onStatusChange("Completado")} style={{
                background: "linear-gradient(135deg, #00C851, #009e3f)",
                border: "none", borderRadius: 8, padding: "9px 18px",
                color: "#fff", fontSize: 13, fontWeight: 700, cursor: "pointer",
                fontFamily: "inherit", boxShadow: "0 0 16px rgba(0,200,81,0.3)",
                display: "flex", alignItems: "center", gap: 6,
              }}
                onMouseEnter={(e) => { e.currentTarget.style.boxShadow = "0 0 24px rgba(0,200,81,0.5)"; }}
                onMouseLeave={(e) => { e.currentTarget.style.boxShadow = "0 0 16px rgba(0,200,81,0.3)"; }}
              >✓ Completar</button>
            ) : (
              <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#00C851", fontSize: 13, fontWeight: 700 }}>✓ Completada</div>
            )}

            {/* Editar */}
            <button onClick={onEdit} style={{
              background: "rgba(0,168,224,0.1)", border: "1px solid rgba(0,168,224,0.3)",
              borderRadius: 8, padding: "9px 18px", color: "#00A8E0",
              fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "inherit",
              display: "flex", alignItems: "center", gap: 6,
            }}
              onMouseEnter={(e) => { e.currentTarget.style.background = "rgba(0,168,224,0.2)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = "rgba(0,168,224,0.1)"; }}
            >✎ Editar</button>
          </div>

          <button onClick={onClose} style={{
            background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)",
            borderRadius: 8, padding: "8px 20px", color: "#aaa",
            fontSize: 13, cursor: "pointer", fontFamily: "inherit",
          }}>Cerrar</button>
        </div>
      </div>
    </div>
  );
}
