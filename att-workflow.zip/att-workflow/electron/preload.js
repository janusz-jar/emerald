const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("api", {
  readTareas:  ()     => ipcRenderer.invoke("read-tareas"),
  writeTareas: (data) => ipcRenderer.invoke("write-tareas", data),
});
