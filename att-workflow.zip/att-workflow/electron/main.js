const { app, BrowserWindow, shell, ipcMain } = require("electron");
const path = require("path");
const fs = require("fs");

const isDev = process.env.NODE_ENV === "development";

// tareas.json vive junto al ejecutable (o en el directorio del proyecto en dev)
const TAREAS_FILE = isDev
  ? path.join(__dirname, "../tareas.json")
  : path.join(path.dirname(app.getPath("exe")), "tareas.json");

// Tareas iniciales que se escriben si el archivo no existe
const DEFAULT_TAREAS = {
  tareas: [
    {
      id: "1",
      titulo: "Alta Repositorio APM ServicesNow",
      area_responsable: "Mexico IT iTAP <Mexico.IT.iTAP@mx.att.com> / Arquitectura Aplicaciones",
      resumen_actividad: "Se requiere tener el APM correspondiente a la aplicación afectada dada de alta en SNOW",
      sla: "3 dias",
      se_trabajar_paralelo: "SI",
      insumos: "se adjunta correo",
      estatus: "Proceso",
      fecha_inicio: "29/04/2026",
      fecha_fin: "",
      evidencias_guias: "Tarea_ALTA_APM_ Apoyo últimos puntos para registro de Aplicación de Negocio TMFProducts.msg",
      categoria: "Alta Aplicación",
      scope: "No Productivo",
      dependencias: []
    },
    {
      id: "2.1",
      titulo: "Alta Repositorio GitHub",
      area_responsable: "Mexico IT Administracion Configuracion <mexicoitadministracionconfiguracion@mx.att.com>",
      resumen_actividad: "La Aplicación de negocio necesita repositorios de código y documentación en github afectada dada de alta en SNOW",
      sla: "3 dias",
      se_trabajar_paralelo: "SI",
      insumos: "Alta Repositorio GitHub MXAPM0002643 SFFEAT0004464 ApiGetBalance Meli consultaSuscriptorMeli-orchestator.msg",
      estatus: "Proceso",
      fecha_inicio: "29/04/2026",
      fecha_fin: "",
      evidencias_guias: "Repositorios GIT",
      categoria: "Alta Aplicación",
      scope: "No Productivo",
      dependencias: []
    },
    {
      id: "2.2",
      titulo: "Alta SonarQube",
      area_responsable: "Mexico IT Calidad de Software <mexicoitcalidaddesoftware@mx.att.com>",
      resumen_actividad: "Se requiere dar de alta el proyecto en SonarQube para análisis de calidad de código",
      sla: "3 dias",
      se_trabajar_paralelo: "SI",
      insumos: "Ticket SNOW con datos de la aplicación",
      estatus: "Pendiente",
      fecha_inicio: "29/04/2026",
      fecha_fin: "",
      evidencias_guias: "Captura de pantalla proyecto SonarQube",
      categoria: "Alta Aplicación",
      scope: "No Productivo",
      dependencias: []
    },
    {
      id: "2.3",
      titulo: "Alta Nexus / Artifactory",
      area_responsable: "Mexico IT Administracion Configuracion <mexicoitadministracionconfiguracion@mx.att.com>",
      resumen_actividad: "Dar de alta los repositorios de artefactos en Nexus/Artifactory para la aplicación",
      sla: "3 dias",
      se_trabajar_paralelo: "SI",
      insumos: "Ticket SNOW y nombre del repositorio",
      estatus: "Pendiente",
      fecha_inicio: "29/04/2026",
      fecha_fin: "",
      evidencias_guias: "Repositorio creado en Nexus",
      categoria: "Alta Aplicación",
      scope: "No Productivo",
      dependencias: []
    },
    {
      id: "3",
      titulo: "Configuración Pipeline CI/CD",
      area_responsable: "Mexico IT DevOps <mexicoitdevops@mx.att.com>",
      resumen_actividad: "Configurar el pipeline de integración y entrega continua en Jenkins/Azure DevOps",
      sla: "5 dias",
      se_trabajar_paralelo: "NO",
      insumos: "Repositorio GitHub creado, SonarQube y Nexus configurados",
      estatus: "Bloqueado",
      fecha_inicio: "",
      fecha_fin: "",
      evidencias_guias: "Pipeline ejecutado exitosamente",
      categoria: "Alta Aplicación",
      scope: "No Productivo",
      dependencias: ["2.1", "2.2", "2.3"]
    },
    {
      id: "4",
      titulo: "Alta en API Gateway",
      area_responsable: "Mexico IT Arquitectura <mexicoitarquitectura@mx.att.com>",
      resumen_actividad: "Registrar los endpoints de la aplicación en el API Gateway corporativo",
      sla: "3 dias",
      se_trabajar_paralelo: "NO",
      insumos: "Especificación OpenAPI/Swagger de los servicios",
      estatus: "Bloqueado",
      fecha_inicio: "",
      fecha_fin: "",
      evidencias_guias: "API registrada y disponible en gateway",
      categoria: "Alta Aplicación",
      scope: "No Productivo",
      dependencias: ["3"]
    },
    {
      id: "5",
      titulo: "Validación y Cierre",
      area_responsable: "Mexico IT iTAP <Mexico.IT.iTAP@mx.att.com>",
      resumen_actividad: "Validar que todos los componentes están correctamente configurados y cerrar el ticket SNOW",
      sla: "2 dias",
      se_trabajar_paralelo: "NO",
      insumos: "Evidencias de todas las tareas anteriores",
      estatus: "Bloqueado",
      fecha_inicio: "",
      fecha_fin: "",
      evidencias_guias: "Ticket SNOW cerrado con evidencias",
      categoria: "Alta Aplicación",
      scope: "No Productivo",
      dependencias: ["1", "3", "4"]
    }
  ]
};

// Lee tareas.json — si no existe lo crea con los defaults
ipcMain.handle("read-tareas", () => {
  try {
    if (fs.existsSync(TAREAS_FILE)) {
      const raw = fs.readFileSync(TAREAS_FILE, "utf-8");
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error("Error leyendo tareas.json:", e);
  }
  // Primera vez: crear el archivo con los defaults
  fs.writeFileSync(TAREAS_FILE, JSON.stringify(DEFAULT_TAREAS, null, 2), "utf-8");
  return DEFAULT_TAREAS;
});

// Escribe tareas.json con el estado completo
ipcMain.handle("write-tareas", (_, data) => {
  try {
    fs.writeFileSync(TAREAS_FILE, JSON.stringify(data, null, 2), "utf-8");
    return { ok: true, path: TAREAS_FILE };
  } catch (e) {
    console.error("Error escribiendo tareas.json:", e);
    return { ok: false, error: e.message };
  }
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: "AT&T Workflow – Receta de Microservicios",
    backgroundColor: "#0a0e1a",
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, "preload.js"),
    },
    frame: true,
    show: false,
  });

  win.once("ready-to-show", () => {
    win.show();
    if (isDev) win.webContents.openDevTools();
  });

  if (isDev) {
    win.loadURL("http://localhost:5173");
  } else {
    win.loadFile(path.join(__dirname, "../dist/index.html"));
  }

  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
