# AT&T Workflow Visualizer

Aplicación de escritorio para visualizar el grafo de dependencias de actividades AT&T México. Construida con **React 18 + ReactFlow + Electron** para portabilidad.

---

## 🚀 Instalación y ejecución

### Requisitos
- Node.js 18+
- npm 9+

### Pasos

```bash
# 1. Instalar dependencias
npm install

# 2. Modo desarrollo (browser)
npm run dev

# 3. Modo desarrollo con Electron (escritorio)
npm run electron:dev

# 4. Build producción (Electron portable)
npm run electron:build
```

El ejecutable se generará en `dist-electron/`.

---

## 📁 Estructura del proyecto

```
att-workflow/
├── electron/
│   └── main.js          # Proceso principal Electron
├── src/
│   ├── App.jsx          # Layout ReactFlow + datos JSON
│   ├── TaskNode.jsx     # Nodo personalizado AT&T
│   ├── TaskModal.jsx    # Modal de detalle de tarea
│   ├── main.jsx         # Entry point React
│   └── index.css        # Estilos globales
├── index.html
├── package.json
└── vite.config.js
```

---

## 🎨 Paleta AT&T

| Color | Uso |
|-------|-----|
| `#00A8E0` | Azul AT&T primario |
| `#F5A623` | Pendiente |
| `#FF4444` | Bloqueado |
| `#00C851` | Completado |
| `#0a0e1a` | Fondo oscuro |

---

## 📊 JSON de Tareas

Editar el arreglo `TASKS` en `src/App.jsx` para actualizar las tareas. Cada tarea acepta:

```json
{
  "id": "1",
  "titulo": "Nombre de la tarea",
  "area_responsable": "Equipo <correo@mx.att.com>",
  "resumen_actividad": "Descripción...",
  "sla": "3 dias",
  "se_trabajar_paralelo": "SI" | "NO",
  "insumos": "...",
  "estatus": "Proceso" | "Pendiente" | "Bloqueado" | "Completado",
  "fecha_inicio": "DD/MM/YYYY",
  "fecha_fin": "DD/MM/YYYY",
  "evidencias_guias": "...",
  "categoria": "...",
  "scope": "Productivo" | "No Productivo",
  "dependencias": ["id1", "id2"]  // IDs de tareas que deben completarse antes
}
```

Tareas con el mismo nivel de dependencias y `se_trabajar_paralelo: "SI"` se muestran en paralelo (mismo nivel horizontal).

---

## ⚡ Funcionalidades

- **Árbol de dependencias** con layout automático por niveles
- **Tareas paralelas** visualmente agrupadas en el mismo nivel
- **Modal de detalle** con click en cualquier nodo: muestra correo, SLA, fechas, insumos, evidencias
- **Links de correo** clickeables (`mailto:`)
- **Minimap** para navegación rápida
- **MiniMap con colores** por estatus
- **Zoom** + pan libre
- **Panel de estadísticas** por estatus

---

*Proyecto AT&T México — Arquitectura Aplicaciones*
